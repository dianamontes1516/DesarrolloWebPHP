<?php
echo "Trabajo completado exitosamente <br>";
echo "El resultado de ".$info['op1']." ".$info['op']."  ".$info['op2']." es : <b>".$respuesta."</b>";
