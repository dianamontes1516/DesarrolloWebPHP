<html>
  <head>
    <meta charset='utf-8' />
  </head>
  <body>
    <?php if (isset($respuesta)): ?>
    <h3>
      <i>
        <?= $respuesta ?>
      </i>
    </h3>
    <?php endif ?>
    <br>

    <form action='control.php' method='POST'>
      <input type='hidden' name='accion' value='minima'/>
      <table>
        <tr><td><p><b> Para probar la función palabra mímina  </b></p></td></tr>
	<tr>
	  <td>Ingresa una cadena solo con caractéres alfanuméricos y espacios</td>
	  <td><input type='text' name='cadena'value="<?=$_POST['cadena']?>"/></td>
	</tr>
	<tr>
	  <td>
	    <input type='submit' value='accion!' />
	  </td>
	</tr>
      </table>
    </form>
  </body>
</html>
