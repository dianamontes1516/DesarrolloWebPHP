<?php
require_once('funciones.php');

/** funci�n que valida entradas del usuario
 * y maneja errores
 * @param cadena - cadena para la funcion
*/
function controlMinima($cadena){
    if(preg_match("/^[a-zA-Z0-9 ]*$/", $cadena)){
        $respuesta =  palabraMinima($cadena);
        die(require_once("resultados.php"));
    }
    $respuesta = "Hubo un error con la cadena, intenta de nuevo";
    die(require_once("minima.php"));
}

/** funci�n que valida entradas del usuario
 * y maneja errores
 * @param info - arreglo que contine los valores necesarios para calcula.
 * las llaves deben ser id�nditas a las usadas en calcula.
*/
function controlCalcula($info){
    $op_validas = ['suma','resta','multiplicacion','division'];
    if(preg_match("/^[0-9]+$/",$info['op1']) && 
       preg_match("/^[0-9]+$/",$info['op2']) &&
       in_array($info['op'], $op_validas)){
	  $respuesta =  calcula($info);
         die(require_once("resultadosC.php"));  
    }
    $respuesta = "Hubo un error con el operador o los operandos";
    die(require_once("calcula.php"));    
}

if($_POST['accion']){
    $info = $_POST;
    print_r($_POST);
    switch($info['accion']){
        case 'minima':
            controlMinima($info['cadena']);
            break;
        case 'calcula':
            controlCalcula($info);
            break;
    }
}

