<html>
  <head>
    <meta charset='utf-8' />
  </head>
  <body>
    <?php if (isset($respuesta)): ?>
    <h3>
      <i>
        <?= $respuesta ?>
      </i>
    </h3>
    <?php endif ?>
    <br>
    <form action='control.php' method='POST'>
	 <input type='hidden' name='accion' value='calcula'/>
      <table>
          <tr><td><p><b> Para probar la función calcula </b></p></td></tr>
	<tr>
	  <td>Seleccione la operación</td>
	  <td>
	    <input type='radio' name='op' value='suma' checked>+
	    <input type='radio' name='op' value='resta'>-
	    <input type='radio' name='op' value='multiplicacion' checked>*
	    <input type='radio' name='op' value='division'>/
	  </td>
	</tr>
	<tr>
	  <td>Operando 1</td>
	  <td><input type='text' name='op1'/></td>
	</tr>
	<tr>
	  <td>Operando 2 </td>
	  <td><input type='text' name='op2'/></td>
	</tr>
	<tr>
	  <td>
	    <input type='submit' value='accion!' />
	  </td>
	</tr>
      </table>
    </form>
  </body>
</html>
