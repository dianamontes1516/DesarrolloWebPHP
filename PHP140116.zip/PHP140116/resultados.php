<?php
echo "Trabajo completado exitosamente <br>";
echo "Palabra con longitud minima es: <b>".$respuesta['minima']."</b>";
