<html>
  <head>
    <meta charset='utf-8' />
  </head>
  <body>
     <h1>Menu</h1>
     <h3>¿Qué función desea probar?</h3>
     <a href='minima.php'> Función de palabra mínima </a>
     <br>
     <a href='calcula.php'> Función de calcula </a>

  </body>
</html>

