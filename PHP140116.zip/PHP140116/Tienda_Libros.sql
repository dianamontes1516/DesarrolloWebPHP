CREATE TABLE administrador (
  login varchar(100) NOT NULL,
  password varchar(100) NOT NULL,
  nombre varchar(100) NOT NULL,
  correo varchar(100) NOT NULL,
  PRIMARY KEY (login)
);

